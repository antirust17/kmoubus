function start() {
		now = new Date(); 
		month = now.getMonth()+1;
		day = now.getDate();
		year = now.getFullYear();		
		weekday = now.getDay();	
		arrText = "기본";
		if (weekday == 0 || weekday == 6) {
				arr = arr1;
				arrText = "토일공휴일 ";
		}
			else {
				//arr =  arr2;
				//arrText = "학기 ";

				arr =  arr3;
				arrText = "방학 ";
			}
		pHour=7;
		pMin=0;
		pHour2=7;
		pMin2=20;
		now.setYear(0);
		now.setMonth(0);
		now.setDate(0);
	    	for(i=0; i<arr.length; i++) {
			  if (arr[i].getTime() - now.getTime() >= 0 ) {
			  		pHour = arr[i].getHours();
			  		pMin = arr[i].getMinutes();
			  		
			  		if (i<(arr.length -1)){
			  			pHour2 = arr[i+1].getHours();
			  			pMin2 = arr[i+1].getMinutes();
			  		}
			  		break;
			  }}

	}
	function checkZero(i) {
		if (i < 10) {i = "0" + i}; // 숫자가 10보다 작을 경우 앞에 0을 붙여줌
		return i;
	}
	function startTime() {
		start();
		now = new Date();
		year = now.getFullYear();
		month = now.getMonth()+1;
		month = checkZero(month);
		day = now.getDate();
		day = checkZero(day); 
		h = now.getHours();
		m = now.getMinutes();
		s = now.getSeconds();
		m = checkZero(m);
		s = checkZero(s);
		
		document.getElementById('nowTime').innerHTML =
		arrText + year+ "." + month +"." + day + ". "+  " " +h + ":" + m + ":" + s ;
		document.getElementById('nextBus').innerHTML =
		"<h1>"+ checkZero(pHour) + ":" + checkZero(pMin) + "</h1>";
		document.getElementById('nNextBus').innerHTML =
		"<h1>"+ checkZero(pHour2) + ":" + checkZero(pMin2) + "</h1>";
		t = setTimeout(startTime, 500);
	}
