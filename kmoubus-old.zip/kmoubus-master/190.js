function start190() {
		now = new Date(); 
		month = now.getMonth()+1;
		day = now.getDate();
		year = now.getFullYear();		
		weekday = now.getDay();	
		arrText190 = "기본";
		if (weekday == 0) {
				arr190 = arr3190;
				arrText190 = "일요일";
		}
		else if (weekday == 6) {
				arr190 = arr2190;
				arrText190 = "토요일";
		}
		else {
				arr190 =  arr1190;
				arrText190 = "평일";
		}
		pHour190=4;
		pMin190=55;
		pHour2190=5;
		pMin2190=7;
		now.setYear(0);
		now.setMonth(0);
		now.setDate(0);
	    	for(i=0; i<arr190.length; i++) {
			  if (arr190[i].getTime() - now.getTime() >= 0 ) {
			  		pHour190 = arr190[i].getHours();
			  		pMin190 = arr190[i].getMinutes();
			  		
			  		if (i<(arr190.length -1)){
			  			pHour2190 = arr190[i+1].getHours();
			  			pMin2190 = arr190[i+1].getMinutes();
			  		}
			  		break;
			  }}

	}
	function checkZero(i) {
		if (i < 10) {i = "0" + i}; // 숫자가 10보다 작을 경우 앞에 0을 붙여줌
		return i;
	}
	function startTime190() {
		start190();
		now = new Date();
		year = now.getFullYear();
		month = now.getMonth()+1;
		month = checkZero(month);
		day = now.getDate();
		day =  checkZero(day);
		h = now.getHours();
		m = now.getMinutes();
		s = now.getSeconds();
		m = checkZero(m);
		s = checkZero(s);
		
		//document.getElementById('nowTime190').innerHTML =
		//year+ "." + month +"." + day + ". "+ arrText + " " +h + ":" + m + ":" + s ;
		document.getElementById('nextBus190').innerHTML =
		"<h1>"+ checkZero(pHour190) + ":" + checkZero(pMin190) + "</h1>";
		document.getElementById('nNextBus190').innerHTML =
		"<h1>"+ checkZero(pHour2190) + ":" + checkZero(pMin2190) + "</h1>";
		t = setTimeout(startTime, 500);
	}
